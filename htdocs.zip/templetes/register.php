<?php
$data = array (
  'type' => 'bubble',
  'size' => 'giga',
  'body' => 
  array (
    'type' => 'box',
    'layout' => 'vertical',
    'contents' => 
    array (
      0 => 
      array (
        'type' => 'text',
        'text' => 'ยินดีตอนรับท่านมาสู่ chatbot for school',
        'margin' => 'none',
        'size' => 'lg',
        'weight' => 'bold',
        'align' => 'center',
      ),
      1 => 
      array (
        'type' => 'separator',
      ),
      2 => 
      array (
        'type' => 'box',
        'layout' => 'vertical',
        'contents' => 
        array (
          0 => 
          array (
            'type' => 'text',
            'text' => 'คุณเป็น',
            'margin' => 'xl',
            'weight' => 'bold',
          ),
          1 => 
          array (
            'type' => 'text',
            'text' => 'ชื่อ : ',
            'margin' => 'none',
            'weight' => 'bold',
          ),
          2 => 
          array (
            'type' => 'text',
            'text' => 'ชั้น : ',
            'weight' => 'bold',
          ),
          3 => 
          array (
            'type' => 'separator',
            'margin' => 'xl',
          ),
        ),
      ),
      3 => 
      array (
        'type' => 'box',
        'layout' => 'vertical',
        'contents' => 
        array (
        ),
      ),
    ),
  ),
);
?>